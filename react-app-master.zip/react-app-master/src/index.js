import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';


const root = ReactDOM.createRoot(document.getElementById('root1')); //it will create space in the browser
root.render(  //show
    <App />
);


